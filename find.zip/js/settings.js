$("#backBtn").click(function(){
    $("#modalBackLays").fadeOut();
});